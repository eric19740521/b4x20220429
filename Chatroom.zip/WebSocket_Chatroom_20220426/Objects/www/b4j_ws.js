//B4J WebSockets client library v0.9

/*jslint browser: true*/
/*global $, jQuery, WebSocket*/
/*jshint curly: false */
"use strict";
var b4j_ws;
var b4j_closeMessage = false;
//only called as a result of a server request that is waiting for result.
//this method should not be called in any other case.
function b4j_sendData(data) {
	console.log("b4j_sendData==>");
	console.log(JSON.stringify({type: "data", data: data}));
	
	
    b4j_ws.send(JSON.stringify({type: "data", data: data}));
}
function b4j_raiseEvent(eventName, parameters) {
    try {
        if (b4j_ws.readyState !== 1) {
            if (b4j_closeMessage === false) {
                window.console.error("connection is closed.");
                window.alert("Connection is closed. Please refresh the page to reconnect.");
                b4j_closeMessage = true;
            }
        } else {
            b4j_ws.send(JSON.stringify({type: "event", event: eventName, params: parameters}));
        }
    } catch (e) {
        window.console.error(e);
    }
}
function b4j_addEvent(selector, event, eventName, preventDefault) {
    var obj = $(selector);
    if (obj.length > 0) {
        obj.on(event, function (e) {
            if (preventDefault) {
                e.preventDefault();
                e.stopPropagation();
            }
            b4j_raiseEvent(eventName, {which: e.which, target: e.target.id, pageX: e.pageX, pageY: e.pageY, metaKey: e.metaKey});
        });
    }
}
function b4j_addAutomaticEvents(data) {
    $.each(data, function (index, value) {
        b4j_addEvent("#" + value.id, value.event, value.id + "_" + value.event, true);
    });
}


function b4j_runFunction(func, params) {
    return window[func].apply(null, params);
}


function b4j_eval(params, script) {
    var f = new Function(script);
    return f.apply(null, params);
}

function b4j_connect(absolutePath) {
    if (typeof WebSocket === 'undefined') {
        window.alert("WebSockets are not supported by your browser.");
        return;
    }
    var l = window.location, fullpath;
    fullpath = ((l.protocol === "https:") ? "wss://" : "ws://") + l.hostname + ":" + l.port + absolutePath;
    b4j_ws = new WebSocket(fullpath);
    b4j_ws.onmessage = function (event) {
		console.log("b4j_ws.onmessage==>");
		console.log("event.data= "+event.data);
		
		//{"type":"data","data":"CCC"}
		//b4j_ws.send(JSON.stringify( {"type":"data","data":"CCC"} ));
		//
		//event.data= {"data":[{"id":"enter","event":"click"}],"etype":"setAutomaticEvents"}
		
		//username.RunMethod("select", Null) 
		//event.data= {"method":"select","etype":"runmethod","id":"#username"}
		//event.data= {"method":"css","etype":"runmethod","id":"username","params":["background-color","#222"]}
        var ed = JSON.parse(event.data);
		
			//txt.RunMethod("select", Null)		
        if (ed.etype === "runmethod") {
			//event.data= {"method":"css","etype":"runmethod","id":"#lbl02","params":["color","red"]}

			//vent.data= {"method":"select","etype":"runmethod","id":"#username"}
            $(ed.id)[ed.method].apply($(ed.id), ed.params);
        } else if (ed.etype === "runmethodWithResult") {
			
			//event.data= {"method":"val","etype":"runmethodWithResult","id":"#username"}
            b4j_sendData($(ed.id)[ed.method].apply($(ed.id), ed.params));
        } else if (ed.etype === "setAutomaticEvents") {//alert("自動綁定事件");


			//event.data= {"data":[{"id":"enter","event":"click"}],"etype":"setAutomaticEvents"}
            b4j_addAutomaticEvents(ed.data);
			

        } else if (ed.etype === "runFunction") {
			
			//event.data= {"prop":"jlog","etype":"runFunction","value":["Enter_Click***>"]}
            b4j_runFunction(ed.prop, ed.value);
        } else if (ed.etype === "runFunctionWithResult") {
			
			//event.data= {"prop":"getABC","etype":"runFunctionWithResult"}
            b4j_sendData(b4j_runFunction(ed.prop, ed.value));
        } else if (ed.etype === "eval") {
			
			//ws.Eval($" document.getElementById("username").value="bbb" "$, Null)
			//event.data= {"prop":"\n\t\tdocument.getElementById(\"username\").value=arguments[0]\n\t","etype":"eval","value":["CCC"]}
            b4j_eval(ed.value, ed.prop);
        } else if (ed.etype === "evalWithResult") {
			
			
			//event.data= {"prop":"\n\tvar a=1;\n\tvar b=2;\n\t\n\treturn a+b;\n\t\n\t","etype":"evalWithResult"}
            b4j_sendData(b4j_eval(ed.value, ed.prop));
        } else if (ed.etype === "alert") {
			
			//event.data= {"prop":"test","etype":"alert"}
            window.alert(ed.prop);
        } else {
		
			alert("請在server建立一個事件");
		}	
        
    };
	
	b4j_ws.onopen = function(e) {
	 console.log("[open] Connection established");
	  //alert("Sending to server");
	  
	   //b4j_ws.send(JSON.stringify( {"prop":"test","etype":"alert"} ));
	};	
	b4j_ws.onclose = function(event) {
	  if (event.wasClean) {
		alert(`[close] 連線已經中斷!!!, code=${event.code} reason=${event.reason}`);
	  } else {
		// 例如服务器进程被杀死或网络中断
		// 在这种情况下，event.code 通常为 1006
		alert('[close] 連線中斷!!');
	  }
	};

	b4j_ws.onerror = function(error) {
	  alert(`[error] ${error.message}`);
	};	
	
}



